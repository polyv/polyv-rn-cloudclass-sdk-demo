## 云课堂移动APP SDK 页面

```bash
npm install
```

### 开发
```bash
npm run dev
```

### 构建
```bash
npm run build
```

### 使用
* 将打包后生成的dist文件夹导入到sdk中，直接使用dist/index.html文件