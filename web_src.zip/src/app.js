/**
 * 该模块作用是处理bridge 与各互动模块的通信
 * 模型: bridge(转发app数据) -> 该模块(转发app数据到互动模块) -> 互动模块(对相应操作的数据发回该模块) -> 该模块(将互动操作数据发回bridge) -> bridge(将互动操作数据发送回app) -> app
 * 每个互动模块都是通过事件将操作数据广播的模式发回当前模块，都通过  {互动模块}.on(event) 监听
 */

import './scss/main.scss';
import bridge from './modules/bridge';
import AnswerCard from './components/answer-card/';
import Questionnaire from './components/questionnaire/';
import Lottery from './components/lottery';
import Sign from './components/sign';
import Announcement from './components/announcement';
import PauseTip from './components/pause-tip';

export default class App {
  /**
   * 为元素添加z-index值，因为可能同时收到多个互动，后到互动需在最上面
   * @param {HTMLElement} el dom元素
   * @param {number} index 需要设置的z-index 值
   */
  static setZIndex(el, index) {
    el.style.zIndex = index;
  }

  /**
   * @return { array } 需要绑定的bridge模块事件
   */
  bridgeEvents() {
    return {
      // 收到答题卡数据
      updateNewQuestion: (data) => {
        this.announcementHandle();
        this.answer.visible = true;
        App.setZIndex(this.answer.wrap, ++this.zIndex);
        // 展示答题卡，注意data是json字符串
        this.answer.updateNewQuestion(JSON.parse(data));
        this.lottery.blur();
      },

      // 收到答题卡结果
      hasChooseAnswer: (data) => {
        this.announcementHandle();
        try{
        let res = JSON.parse(data);
        this.answer.visible = true;
        App.setZIndex(this.answer.wrap, ++this.zIndex);
        this.answer.hasChooseAnswer(res.answerId, res.data);
        this.lottery.blur(); // 去除抽奖输入框焦点，其他模块同理，因为这个输入框在部分机型有怪异行为
        } catch(e) {}
      },

      extraQuestionMessageHandler: (data) => {
        this.announcementHandle();
        const res = JSON.parse(data);
        if (res.type === 'S' || res.EVENT !== 'STOP_TEST_QUESTION') return;
        this.answer.visible = true;
        App.setZIndex(this.answer.wrap, ++this.zIndex);
        this.answer.stopQuestion(res);
        this.lottery.blur();
      },

      // 收到问卷消息
      startQuestionNaire: (data) => {
        this.announcementHandle();
        this.questionnaire.visible = true;
        App.setZIndex(this.questionnaire.el, ++this.zIndex);
        this.questionnaire.startQuestionNaire(JSON.parse(data));
        this.lottery.blur();
      },

      // 收到停止问卷消息
      stopQuestionNaire: (data) => {
        this.announcementHandle();
        this.questionnaire.visible = true;
        this.questionnaire.stopQuestionNaire(JSON.parse(data));
      },

      // 开始抽奖
      startLottery: () => {
        this.announcementHandle();
        this.lottery.visible = true;
        this.lottery.startLottery();
        App.setZIndex(this.lottery.wrap, ++this.zIndex);
      },

      // 抽奖结束，data数据包含中奖信息
      stopLottery: (data) => {
        this.announcementHandle();
        this.lottery.visible = true;
        this.lottery.stopLottery(JSON.parse(data));
      },

      // 收到关闭抽奖信息
      closeLotteryWinner: () => {
        this.announcementHandle();
        this.lottery.closeLotteryWinner();
      },

      // 开始签到
      startSign: (data) => {
        this.announcementHandle();
        this.sign.visible = true;
        this.sign.startSign(JSON.parse(data));
        App.setZIndex(this.sign.wrap, ++this.zIndex);
        this.lottery.blur();
      },

      // 停止签到
      stopSign: () => {
        this.sign.stopSign();
      },

      // 收到公告
      bulletin: (data) => {
        this.announcement.append(JSON.parse(data).content);
      },

      // 移除公告
      removeBulletin: () => {
        this.announcement.remove();
      },

      // 开始直播
      onStartRecord: () => {
        this.pauseTip.hide();
      },

      // 暂停直播
      onPauseRecord: (data) => {
        this.announcementHandle();
        this.pauseTip.append(JSON.parse(data).tip);
      },

      // 退出直播
      onExitRecord: () => {
        this.pauseTip.hide();
      },
    }
  }

  /**
   * 绑定桥接事件
   * @return void
   */
  bindBridgeEvents() {
    this.eventLists = this.bridgeEvents();
    Object.keys(this.eventLists).forEach(event => {
      bridge.on(event, this.eventLists[event]);
    });
  }

  /**
   * 在当前暂无公告情况下收到其他互动需调用，隐藏公告模块
   */ 
  announcementHandle() {
    if (this.announcement.emptyAndVisible) {
      this.announcement.hide();
    }
  }

  constructor(els = {}) {
    // 初始化响应模块，都是通过传入一个元素id
    this.answer = new AnswerCard(els.answerCard);
    this.questionnaire = new Questionnaire(els.questionnaire);
    this.lottery = new Lottery(els.lottery);
    this.sign = new Sign(els.sign);
    this.announcement = new Announcement(els.announcement);
    this.pauseTip = new PauseTip(els.pauseTip);
    // 隐藏样式class
    this.hideClass = 'ppt-hide';
    // z-index值，使用加一
    this.zIndex = 10;

    // 绑定brige的事件列表
    this.eventLists = null;

    // 监听响应模块的事件
    this.bindBridgeEvents();
    this.bindAnswerEvent();
    this.bindQuestionnaireEvent();
    this.bindLotteryEvent();
    this.bindSignEvent();
    this.bindAnnouncementEvent();
    this.bindPauseTipEvent();
    let clk = setTimeout(() => {
      bridge.initWebview();
    }, 200);
    bridge.on('bridgeInit', () => {
      clearTimeout(clk);
      setTimeout(() => {
        bridge.initWebview();
      }, 200);
    });
  }

  /**
   * 通知bridge关闭webview，所有关闭操作都是调用该方法，先判断是否还有模块为关闭，全关闭了就告诉app关闭webview
   */
  closeWebview() {
    if (!this.answer.visible && !this.questionnaire.visible && !this.sign.visible && !this.lottery.visible && !this.announcement.visible && !this.pauseTip.visible) {
      bridge.closeWebview();
    }
  }

  bindAnswerEvent() {
    this.answer.on('knowAnswer', () => {
      this.answer.visible = false;
      this.closeWebview();
    });
    this.answer.on('chooseAnswer', (data) => {
      bridge.chooseAnswer(data);
      this.answer.visible = false;
      this.closeWebview();
    });
  }

  bindQuestionnaireEvent() {
    this.questionnaire.on('endQuestionnaireAnswer', (data) => {
      bridge.endQuestionnaireAnswer(data);
      this.questionnaire.visible = false;
      this.closeWebview();
    });
    this.questionnaire.on('stopQuestionNaire', () => {
      this.questionnaire.el.classList.add(this.hideClass);
      this.questionnaire.visible = false;
      this.closeWebview();
    });
  }

  bindLotteryEvent() {
    this.lottery.on('sendWinData', (data) => {
      this.lottery.visible = false;
      bridge.sendWinData(data);
    });
    this.lottery.on('abandonLottery', (data) => {
      this.lottery.visible = false;
      bridge.abandonLottery();
    });
    this.lottery.on('closeLotteryWebview', () => {
      this.lottery.visible = false;
      this.closeWebview();
    });
    if (/iPad|iPhone|iPod/i.test(navigator.userAgent)) {
      window.addEventListener('orientationchange', () => {
        this.lottery.blur();
      }, false);
    }
  }

  bindSignEvent() {
    this.sign.on('submitSign', () => {
      this.sign.visible = false;
      bridge.submitSign();
    });
    this.sign.on('closeSignWebview', () => {
      this.sign.visible = false;
      this.closeWebview();
    });
  }

  bindAnnouncementEvent() {
    this.announcement.on('close', this.closeWebview.bind(this));
    this.announcement.on('linkClick', (data) => bridge.linkClick(data));
  }

  bindPauseTipEvent() {
    this.pauseTip.on('close', this.closeWebview.bind(this));
  }
};
