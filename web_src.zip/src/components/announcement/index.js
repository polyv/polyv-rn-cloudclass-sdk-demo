import './announcement.scss';
import Event from 'events';

export default class Announcement extends Event {
  constructor(idSelector, isPc) {
    super();
    this.visible = false;
    // 当前是否有内容
    this.empty = true;
    this.isPc = isPc || false;
    this.el = document.getElementById(idSelector);
    this.els = [...this.el.querySelectorAll('[data-el]')].reduce((els, el) => {
      els[el.getAttribute('data-el')] = el;
      return els;
    }, {});

    this.bindCloseEvent();
  }

  get emptyAndVisible() {
    return this.empty && this.visible;
  }

  bindCloseEvent() {
    const func = () => {
      this.hide();
      this.emit('close');
      this.remove();
    };

    !this.isPc && this.els.close.addEventListener('click', func);
    this.els.know.addEventListener('click', func);
  }

  show() {
    this.visible = true;
    this.el.classList.remove('ppt-hide');
  }

  hide() {
    this.visible = false;
    this.el.classList.add('ppt-hide');
  }

  append(content, show = true) {
    this.els.content.innerHTML = content || '暂无公告';
    this.empty = !content;
    if (show) {
      this.show();
      this.bindLinkEvent();
    }
  }

  remove() {
    this.append('', false);
  }

  bindLinkEvent() {
    const a = this.el.querySelectorAll('a');
    const that = this;
    a.forEach((item) => {
      item.addEventListener('click', function(e) {
        that.emit('linkClick', e.target.href);
        e.preventDefault();
      });
    });
  }
}
