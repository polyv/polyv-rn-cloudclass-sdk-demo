import './answer.scss';
import Event from 'events';

const words = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

const tmp = {

  parseString(str) {
    return str.replace(/</g, '&lt;').replace(/>/g, '&gt;').trim();
  },

  questionTypeTxt(type) {
    return type === 'C' ? '多选' : '单选';
  },

  isMultiSelect(type) {
    return type === 'C';
  },

  getStatusClass(type) {
    let cls = '';
    switch (type) {
      case 'success':
        cls = 'answer-right';
        break;
      case 'error':
        cls = 'answer-error';
        break;
      case 'checked':
        cls = 'answer-checked';
        break;
      case 'selectRight':
        cls = 'answer-right-select';
        break;
      case 'normal':
        cls = 'answer-normal';
        break;
      case 'noselect':
        cls = 'no-select';
        break;
      default:
    }

    return cls;
  },

  option({ ratio = '0', contain = '', type = '', index, count = '' }) {
    if(!contain) return '';
    return `
    <li class="${this.getStatusClass(type)}" data-options="${index}">
      <div class="ppt-answer-ratio" style="width:${ratio}"></div>
      <div class="ppt-answer-option">${index}. ${this.parseString(contain)}</div>
      <span class="ppt-answer-count">${count}</span>
    </li>
    `;
  },

  getOptions(options) {
    const selectsNumbers =  Object.keys(options)
    .filter((item) => item.indexOf('option') !== -1 && options[item])
    .length;
    let txt = '';
    for (let i = 0; i < selectsNumbers; i++) {
      txt += this.option( {
        contain: options[`option${i + 1}`],
        index: words[i],
        type:  options[`type${i + 1}`],
        ratio: options[`ratio${i + 1}`] || 0,
        count: options[`result${i + 1}`]
      })
    }
    return txt;
  },

  card(options) {
    const id = `id-${new Date().getTime()}`;
    const el = document.createElement('div');
    el.setAttribute('class', `ppt-answer-card ${options.tipsClass || ''}`);
    el.innerHTML = `<div class="ppt-answer-head">
      ${options.tips}
      <span class="ppt-answer-close" data-type="close">×</span>
    </div>
    <div class="ppt-answer-contain">
      <h3>【${this.questionTypeTxt(options.type)}】${this.parseString(options.title || options.name)}</h3>
      <ul class="ppt-answer-list">
        ${this.getOptions(options)}
      </ul>
    </div>
    <div class="ppt-answer-foot">
      <span id="${id}" class="ppt-answer-btn ${options.btnClass || ''}" data-type="${options.submitType}">${options.btn}</span>
    </div>`;

    return {el, id};
  },

  tips(txt) {
    const el = document.createElement('div');
    el.textContent = txt;
    el.classList.add('ppt-answer-tips');
    return el;
  }
};


class AnswerCard extends Event {

  updateNewQuestion(data) {
    if (data.type === 'S') {
      this.emit('knowAnswer');
      return;
    }
    this.visible = true;
    this.currentStatus = {
      id: data.questionId,
      type: 'commit'
    };

    this.selectOptions = [];
    const newData = Object.assign({
      submitType: 'commit',
      btn: '提交答案',
      tips: '答题卡'
    }, data);
    this.initElement(newData, true, data.questionId, tmp.isMultiSelect(newData.type));
  }

  hasChooseAnswer(select, data) {
    if (data.type === 'S') {
      this.emit('knowAnswer');
      return;
    }

    this.visible = true;
    this.currentStatus = {
      id: data.questionId,
      type: 'close'
    };
    // await this.delay();
    // 没上次记录或者不是同一条问题不处理
    // const answerData = this.data[data.questionId] || {};
    data.result = data.data || data.result;
    const resultData = this.createResultData(select, data.result);
    const tipsData = this.getResultTips(select, data.result.answer, data.questionId);
    const newData = Object.assign({
      submitType: 'close',
      btn: '知道了',
      btnClass: 'answer-primary',
      tips: tipsData.tips,
      tipsClass: tipsData.tipsClass
    }, resultData, data, data.content);

    this.initElement(newData, false);
  }

  stopQuestion(data) {
    if (!this.el || this.currentStatus.type !== 'commit' || this.currentStatus.id !== data.questionId) {
      this.emit('knowAnswer');
      return;
    };
    this.currentStatus.type = 'stop';
    const cls = tmp.getStatusClass('checked');
    this.btn.classList.remove('answer-primary');
    this.btn.textContent = '已截止';
    this.selectOptions = [];
    [...this.el.querySelectorAll(`.${cls}`)].forEach(item => {
      item.classList.remove(cls);
    });
  }

  initElement(newData, bindOption, questionId, isMultiSelect = false) {
    this.removeCard();
    const card = tmp.card(newData);
    this.el = card.el;
    this.wrap.appendChild(this.el);
    this.btn = document.getElementById(card.id);
    this.wrap.classList.add('answer-show');
    this.bindEvent(bindOption, questionId, isMultiSelect);
  }

  getResultTips(select, answer, id) {
    const result = select || '';
    let tips = '';
    let tipsClass = '';
    if (!result) {
      tips = '未作答';
    } else if (result === answer) {
      tips = '回答正确';
      tipsClass = tmp.getStatusClass('success');
    } else {
      tips = '回答错误';
      tipsClass = tmp.getStatusClass('error');
    }

    return {
      tips,
      tipsClass
    };
  }

  createResultData(select, result) {
    const obj = {};
    const selectOptions = select.split('');
    result.singleResult.forEach((item, index) => {
      const currentSelect = words[index];
      console.log(currentSelect);
      obj[`result${index + 1}`] = item;
      obj[`ratio${index + 1}`] = item / (result.total || 1) * 100 + '%';
      obj[`type${index + 1}`] = this.getAnswerType(result.answer, currentSelect, selectOptions.indexOf(currentSelect) !== -1, item);
    });

    return obj;
  }

  getAnswerType(answer, currentSelect, isSelect, ratio) {
    const isRight = answer.indexOf(currentSelect) !== -1;
    if (isRight && isSelect) {
      return 'selectRight';
    } else if(!ratio && isRight) {
      return 'noselect';
    }else if (isRight) {
      return 'success';
    } else if (!isRight && isSelect) {
      return 'error';
    } else {
      return 'normal';
    }
  }

  bindEvent(bindOption, questionId, isMultiSelect = false) {
    const _this = this;
    let currentEl = null;

    this.el.addEventListener('click', (event) => {
      const type = event.target.getAttribute('data-type');
      if (!type) return;
      if (type === 'close') {
        this.removeCard();
        this.emit('knowAnswer');
      }

      if (type === 'commit') {
        this.commit(questionId);
      }
    });

    bindOption && this.el.addEventListener('click', (event) => {
      if (this.currentStatus.type === 'stop') return;
      let bool = true;
      let target = event.target;
      let option = null;
      while (bool) {
        option = target.getAttribute('data-options');
        if (option) {
          bool = false;
          break;
        }
        if (target === this.el) {
          bool = false;
          target = null;
          break;
        }
        target = target.parentNode;
        if(!target) break;
      }

      if (!option) return;

      if (isMultiSelect) {
        this.multiHandler(target, option);
      } else {
        currentEl = this.singleHandler(currentEl, target, option);
      }
    })
  }

  multiHandler(el, option) {
    const cls = tmp.getStatusClass('checked');
    const index = this.selectOptions.indexOf(option);
    if (index > -1) {
      this.selectOptions.splice(index, 1);
    } else {
      this.selectOptions.push(option);
    }

    if (this.selectOptions.length > 0) {
      this.btn.classList.add('answer-primary');
    } else {
      this.btn.classList.remove('answer-primary');
    }
    el.classList.toggle(cls);
  }

  singleHandler(currentEl, el, option) {
    const cls = tmp.getStatusClass('checked');
    if (currentEl) currentEl.classList.remove(cls);
    el.classList.add(cls);
    this.selectOptions = [option];
    this.btn.classList.add('answer-primary');
    return el;
  }

  sortResult(ary = []) {
    return ary.sort().join('');
  }

  commit(questionId) {
    const result = this.sortResult(this.selectOptions);
    if (!result) return;
    this.removeCard();

    this.showTips('提交成功', 1.5, () => {
      this.emit('chooseAnswer', {
        answerId: result,
        questionId
      });
    });
  }

  removeCard() {
    if (this.el) {
      this.wrap.removeChild(this.el);
      this.el = null;
      this.wrap.classList.remove('answer-show');
    }
  }

  showTips(txt, duration = 2, cb = function(){}) {
    const tips = tmp.tips(txt);
    this.wrap.appendChild(tips);
    this.wrap.classList.add('answer-show');
    if (duration) {
      setTimeout(() => {
        this.wrap.removeChild(tips);
        this.wrap.classList.remove('answer-show');
        cb();
      }, duration * 1000);
    }
  }

  constructor(wrap) {
    super();
    this.wrap = document.getElementById(wrap);  // 显示答题卡容器
    this.el = null; // 答题卡元素
    this.btn = null; // 提交按钮
    this.visible = false; // 当前是否显示
    this.selectOptions = []; // 已选项
    this.currentStatus = {}; // 当前答题卡状态
  }
}

export default AnswerCard;



