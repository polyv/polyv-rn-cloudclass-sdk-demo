/**
 * version=3 添加地址栏
 *  */ 

import './lottery.scss';
import Event from 'events';

function getUrlParam(key) {
  // 获取参数
  const url = window.location.search;
  // 正则筛选地址栏
  const reg = new RegExp(`(^|&)${key}=([^&]*)(&|$)`);
  // 匹配目标参数
  const result = url.substr(1).match(reg);
  // 返回参数值,过滤空格
  return result ? decodeURIComponent(result[2].replace(/\s*/g, '')) : null;
}

const version = getUrlParam('version');

const ADDRESS = version === '3';

const tmp = {
  lotteryStart() {
    const el = document.createElement('div');
    el.setAttribute('class', 'lottery-start-content el-lottery-content');
    el.innerHTML = `<span class="lottery-start-gif">正在抽奖</span>
      <span class="lottery-start-close" data-type="close">×</span>`;
    return el;
  },

  lotteryMainContainer(data = { prize: '', winnerCode: '' }) {
    const el = document.createElement('div');
    el.setAttribute('class', 'lottery-main-container el-lottery-content');
    el.innerHTML = `
      <span class="lottery-main-close" data-type="lottery-close">×</span>
      <div class="lottery-main-head">
        <p>中奖啦</p>
        <p>${data.prize}</p>
        <span>兑换码：${data.winnerCode}</span>
      </div>
      <p>—— 请提交以下信息，后续有专人联系您兑奖 ——</p>
      <div class="lottery-submit-data">
        <input class="lottery-name" id="lotteryName" type="text" placeholder="请输入真实姓名">
        <input class="lottery-tel" id="lotteryTel" type="text" placeholder="请输入手机号码">
        ${ADDRESS ? '<input class="lottery-adr" id="lotteryAdr" type="text" placeholder="请输入收件地址">' : ''}
      </div>
      <button class="lottery-submit" id="lotterySubmit" data-type="submit-lottery">提交</button>
    `;
    return el;
  },

  lotteryNotWin() {
    const el = document.createElement('div');
    el.setAttribute('class', 'lottery-not-win el-lottery-content');
    el.innerHTML = `
      <p>很遗憾您未中奖</p>
      <button data-type="close-webview">知道了</>
    `;
    return el;
  },

  lotteryPrompt(txt = '') {
    const el = document.createElement('div');
    el.setAttribute('class', 'lottery-prompt ppt-hide');
    el.innerHTML = txt;
    return el;
  }
}

class Lottery extends Event {
  constructor(wrap) {
    super();
    this.specailCh = false;  // 是否有特殊字符
    this.wrongNum = false;  // 是否为正确手机号
    this.addressLegal = true; // 地址是否合法
    this.visible = false;
    this.nameValue = null,
    this.telephoneNumber = null;
    this.addressValue = null;
    this.timer = null;
    this.wrap = document.getElementById(wrap);
    this.bindEvent();
  }
  // 开始抽奖
  startLottery(data) {
    this.closeElement();
    this.visible = true;
    this.el = tmp.lotteryStart();
    this.wrap.appendChild(this.el);
    this.wrap.classList.add('lottery-show');
  }
  // 中奖
  winLottery(data) {
    this.el = tmp.lotteryMainContainer(data);
    this.wrap.appendChild(this.el);
    const prompt = tmp.lotteryPrompt();
    this.el.appendChild(prompt);
    this.promptEl = document.getElementsByClassName('lottery-prompt')[0];
    this.inputCheck();
  }
  // 未中奖
  notWinLottery() {
    this.el = tmp.lotteryNotWin();
    this.wrap.appendChild(this.el);
  }

  stopLottery(data) {
    this.closeElement();
    this.visible = true;
    if (data.win) {
      this.winLottery(data);
    } else {
      this.notWinLottery();
    }
    this.wrap.classList.add('lottery-show');
  }

  closeElement() {
    if (document.getElementsByClassName('el-lottery-content')[0]) {
      this.el.remove();
      this.el = null;
      this.wrap.classList.remove('lottery-show');
    }
  }

  closeLotteryWinner() {
    const isAbandon = confirm('确认放弃领取奖品？');
    if (isAbandon) {
      this.emit('abandonLottery');
      this.closeElement();
      this.emit('closeLotteryWebview');
    }
  }

  bindEvent() {
    this.wrap.addEventListener('click', (event) => {
      const type = event.target.getAttribute('data-type');
      if (!type) return;
      switch(type) {
        case 'close':
          this.closeElement();
          this.emit('closeLotteryWebview');
          break;
        case 'submit-lottery':
          if (this.checkAllowSubmit()) {
            this.tipsShow('请填写正确信息');
            break;
          }
          const data = {
            name: this.nameValue,
            telephone: this.telephoneNumber
          };
          if (ADDRESS) {
            data.address = this.addressValue;
          }
          this.emit('sendWinData', data);
          this.tipsShow('提交成功').then(() => {
            this.closeElement();
            this.emit('closeLotteryWebview');
          });
          break;
        case 'lottery-close':
          const isAbandon = confirm('确认放弃领取奖品？');
          if (isAbandon) {
            this.emit('abandonLottery');
            this.closeElement();
            this.emit('closeLotteryWebview');
          }
          break;
        case 'close-webview':
          this.closeElement();
          this.emit('closeLotteryWebview');
          break;
        default: break;
      }
    });
  }

  blur() {
    const nameEl = document.getElementById('lotteryName');
    const telephoneEl = document.getElementById('lotteryTel');

    if (nameEl) nameEl.blur();
    if (telephoneEl) telephoneEl.blur();
  }

  // 提示语
  tipsShow(txt) {
    this.promptEl.innerHTML = txt;
    this.promptEl.classList.remove('ppt-hide');
    return new Promise(resolve => {
      clearTimeout(this.timer);
      this.timer = setTimeout(() => {
        this.promptEl.classList.add('ppt-hide');
        resolve();
      }, 3000);
    });
  }

  checkAllowSubmit() {
    return this.specailCh || this.wrongNum || !this.nameValue || !this.telephoneNumber || !this.addressLegal;
  }
 
  checkSpecailChar(text) {
    const ranges = [
      '\ud83c[\udf00-\udfff]', // U+1F300 to U+1F3FF
      '\ud83d[\udc00-\ude4f]', // U+1F400 to U+1F64F
      '\ud83d[\ude80-\udeff]' // U+1F680 to U+1F6FF
    ];
    return !!text.match(ranges.join('|'));
  }

  // 输入框检测
  inputCheck() {
    const nameEl = document.getElementById('lotteryName');
    const telephoneEl = document.getElementById('lotteryTel');
    this.nameValue = '';
    this.telephoneNumber = '';
    this.addressValue = '';

    nameEl.addEventListener('blur', (e) => {
      let name = e.target.value;
      if (name.length > 10) {
        name = name.substr(0, 10);
        nameEl.value = name;
      }
      this.specailCh = this.checkSpecailChar(name);
      if (this.specailCh) this.tipsShow('不可输入特殊字符');
      this.nameValue = name;
    });
    telephoneEl.addEventListener('keyup', e => {
      let tel = e.target.value;
      telephoneEl.value = tel.replace(/[^0-9.]/g, '');
      if (tel.length > 11) {
        tel = tel.substr(0, 11);
        telephoneEl.value = tel
      }
    });
    telephoneEl.addEventListener('blur', (e) => {
      const tel = e.target.value;
      const re = /^1\d{10}$/;
      const phoneRe = /^1[3456789]\d{9}$/;
      if (!re.test(tel) || !phoneRe.test(tel)) {
        this.tipsShow('请输入正确号码');
        this.wrongNum = true;
      } else {
        this.wrongNum = false;
      }
      this.telephoneNumber = tel;
    });

    if (ADDRESS) {
      const adrEl = document.getElementById('lotteryAdr');
      adrEl.addEventListener('blur', (e) => {
        let val = e.target.value;
        this.addressLegal = !this.checkSpecailChar(val);
        console.log(this.addressLegal, val);
        if (!this.addressLegal) this.tipsShow('不可输入特殊字符');
        this.addressValue = val;
      });
    }
  }
}

export default Lottery;
