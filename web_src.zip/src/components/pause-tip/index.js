import './pause-tip.scss';
import Event from 'events';

export default class PauseTip extends Event {
  constructor(idSelector, isPc) {
    super();
    this.visible = false;
    this.isPc = isPc || false;
    this.el = document.getElementById(idSelector);
    this.els = [...this.el.querySelectorAll('[data-el]')].reduce((els, el) => {
      els[el.getAttribute('data-el')] = el;
      return els;
    }, {});

    this.bindCloseEvent();
  }

  bindCloseEvent() {
    const func = () => {
      this.hide();
    };

    !this.isPc && this.els.close.addEventListener('click', func);
    this.els.know.addEventListener('click', func);
  }

  show() {
    this.visible = true;
    this.el.classList.remove('ppt-hide');
  }

  hide() {
    this.visible = false;
    this.el.classList.add('ppt-hide');
    this.append('', false);
    this.emit('close');
  }

  append(tip, show = true) {
    this.els.content.innerHTML = tip || '';
    if (show) {
      this.show();
    }
  }
}
