import './questionnaire.scss';
import resultTmp from './resultTmp';
import Event from 'events';

const words = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

const tmp = {
  parseString(str) {
    if (!str || typeof str === 'number') return str;
    return str.replace(/</g, '&lt;').replace(/>/g, '&gt;').trim();
  },

  layout({ questions, title = '' }, isClient) {
    const layoutClass = isClient ? 'live-questionnaire-pc' : 'live-questionnaire-mobile';
    const headTxt = isClient ? ''
      : `<div class="live-questionnaire-head">
    ${this.parseString(title)}
    <span data-type="close">×</span>
    </div>`;
    const el = document.createElement('div');
    el.setAttribute('class', `live-questionnaire ${layoutClass}`);
    el.innerHTML = `
    ${headTxt}
    <div class="live-questionnaire-container">
      <div class="live-questionnaire-content js-questionnaireContent">

      </div>
    </div>`.trim();
    return el;
  },

  option(type, text = '', index) {
    text = this.parseString(text);
    return `
    <div class="live-questionnaire-option live-questionnaire-option-${type}" title="${text}" data-answer="${words[index]}">
      <span>${words[index]}.${text}</span>
    </div>
    `.trim();
  },

  textarea() {
    return `
      <textarea></textarea>
    `.trim();
  },

  btn() {
    const el = document.createElement('div');
    el.setAttribute('class', 'live-questionnaire-foot');
    el.innerHTML = '<span data-type="submit">提交</span>';
    return el;
  },

  question(data) {
    let answer;
    if (data.type === 'Q') {
      answer = this.textarea();
    } else {
      const ary = [];
      data.options.forEach((item, index) => {
        if (index % 2 === 0) {
          ary.push([item]);
        } else {
          ary[ary.length - 1].push(item)
        }
      });
      let index = 0;
      answer = ary.reduce((prev, next) => {
        return `${prev}<div class="live-questionnaire-question-col">${this.option(data.type, next[0], index++)}${next[1] ? this.option(data.type, next[1], index++) : ''}</div>`
      }, '');
    }

    const el = document.createElement('div');
    el.setAttribute('class', 'live-questionnaire-question');
    el.innerHTML = `<div class="live-questionnaire-question-head">${data.index}、${this.parseString(data.name)}<sup>${data.required ? '*' : ''}</sup>${data.type === 'C' ? ' <span>(多选)</span>' : ''}</div>
      <div class="live-questionnaire-question-error ppt-hide js-questionnaireError"><span>这道题必填哦</span></div>
      <div class="js-questionnaireOption">${answer}</div>`.trim();
    return el;
  },

  tips(txt) {
    const el = document.createElement('div');
    el.setAttribute('class', 'live-questionnaire-tips');
    el.textContent = txt;
    return el;
  }
};

class Questionnaire extends Event {

  constructor(selector, isClient = false) {
    super();
    this.visible = false;
    this.el = document.getElementById(selector);
    // this.chat = cloud.chat;
    this.id;
    this.isClient = isClient;
    this.config = {};
    // 已经结束的问卷
    this.idLists = [];

    if (typeof this.config.startCallback !== 'function') {
      this.config.startCallback = function() {}
    }

    if (typeof this.config.endCallback !== 'function') {
      this.config.endCallback = function() {}
    }

    if (typeof this.config.successCallback !== 'function') {
      this.config.successCallback = function() {}
    }
  }

  singleHandler(el, answer, data) {
    if (data.answer === answer) return;

    if (data.currentEl) {
      data.currentEl.classList.remove('checked');
    }

    if (data.required && data.showError) {
      data.showError = false;
      data.tips.classList.add('ppt-hide');
    }

    el.classList.add('checked');
    data.answer = answer;
    data.currentEl = el;
  }

  multiHandler(el, answer, data) {
    if (!data.answer) {
      data.answer = {};
    }

    if (data.answer[answer]) {
      el.classList.remove('checked');
      delete data.answer[answer];
    } else {
      el.classList.add('checked');
      data.answer[answer] = true;
    }

    if (data.required && data.showError && Object.keys(data.answer).length > 0) {
      data.showError = false;
      data.tips.classList.add('ppt-hide');
    }
  }

  askHandler(el, data) {
    el.querySelector('textarea').addEventListener('change', (event) => {
      data.answer = event.target.value.trim();
      if (data.required && data.showError && data.answer) {
        data.showError = false;
        data.tips.classList.add('ppt-hide');
      }
    });
  }

  initOptionHandler(data) {
    const _this = this;
    if (data.type === 'Q') {
      this.askHandler(data.el, data);
    } else {
      data.el.addEventListener('click', (event) => {
        let target = event.target;
        let answer;
        let bool = true;
        while (bool) {
          answer = target.getAttribute('data-answer');
          if (answer || target === data.el) {
            bool = false;
            break;
          } else {
            target = target.parentNode;
          }
        }

        if (!answer) return;

        if (data.type === 'R') {
          this.singleHandler(target, answer, data);
        } else {
          this.multiHandler(target, answer, data);
        }
      });
    }
  }

  initBtnHandler() {
    this.data.el.addEventListener('click', (event) => {
      let target = event.target;
      let type;
      let bool = true;
      while (bool) {
        type = target.getAttribute('data-type');
        if (type || target === this.data.el) {
          bool = false;
          break;
        } else {
          target = target.parentNode;
        }
      }

      if (!type) return;
      const $scrollTarget = this.data.el.querySelector('.live-questionnaire-container');
      if (type === 'close') {
        this.remove();
        this.emit('stopQuestionNaire');
        this.config.endCallback();
      }
      if (type === 'submit') {
        if (!this.data.allow) return;
        const answers = [];
        let legal = true;
        let scroll = false;
        this.data.questions.forEach(question => {
          let answer = question.answer;
          if (question.type === 'C') {
            answer = answer || {};
            answer = Object.keys(answer).sort().join('');
          }

          if (question.type === 'Q') {
            answer = tmp.parseString(answer);
          }

          if (question.required && !answer) {
            legal = false;
            question.tips.classList.remove('ppt-hide');
            question.showError = true;
            if(!scroll) {
              $scrollTarget.scrollTop = question.el.offsetTop - 60;
              scroll = true;
            }
          } else {
            answers.push({
              questionId: question.id,
              answer: answer
            });
          }
        });

        if (!legal) return;
        const id = this.data.id;
        this.showTips('提交成功', 'success', () => {
          this.emit('endQuestionnaireAnswer', { id, answers });
          this.el.classList.add('ppt-hide');
        });
        this.remove();
      }
    })
  }

  showTips(msg, type = 'success', cb = function() {}) {
    const el = tmp.tips(msg);
    el.classList.add(`live-questionnaire-tips-${type}`);
    this.el.appendChild(el);
    setTimeout(() => {
      this.el.removeChild(el);
      cb();
    }, 2000);
  }

  remove() {
    this.el.removeChild(this.data.el);
    this.data = undefined;
  }

  render() {
    const layout = tmp.layout(this.data, this.isClient);
    const content = layout.querySelector('.js-questionnaireContent');
    this.data.questions.forEach(question => {
      question.el = tmp.question(question);
      question.tips = question.el.querySelector('.js-questionnaireError');
      content.appendChild(question.el);
      this.initOptionHandler(question);
    });
    this.data.btn = tmp.btn();
    content.appendChild(this.data.btn);
    this.el.appendChild(layout);
    this.data.el = layout;
    this.initBtnHandler();
  }

  formatQuestions(questions) {
    return questions.map((question, index) => {
      return {
        required: question.required === 'Y',
        type: question.type,
        name: tmp.parseString(question.name),
        id: question.questionId,
        index: index + 1,
        options: Array.from(new Array(10)).map((item, index) => question[`option${index + 1}`]).filter(option => !!tmp.parseString(option))
      };
    });
  }

  startQuestionNaire(data) {
    this.el.classList.remove('ppt-hide');
    if (this.idLists.indexOf(data.questionnaireId) !== -1) {
      return;
    }
    if (this.data) {
      if (this.data.id === data.content.questionnaireId) {
        return;
      }
      this.remove();
    }

    this.config.startCallback();
    this.data = {
      title: tmp.parseString(data.content.questionnaireTitle),
      id: data.content.questionnaireId,
      questions: this.formatQuestions(data.content.questions),
      allow: true
    }

    this.render();
  }

  stopQuestionNaire(data) {
    this.idLists.push(data.questionnaireId);
    if(!this.data) {
      this.emit('stopQuestionNaire');
      return;
    };
    this.showTips('问卷已截止', 'stop', () => {
      this.emit('stopQuestionNaire');
    });
    this.remove();
  }

  returnResutQuestionnaire(data) {
    const els = resultTmp.mainTmp(data);
    this.el.classList.remove('ppt-hide');
    this.el.appendChild(els);
    document.getElementById('questionnaireResultClose').addEventListener('click', () => {
      this.el.removeChild(els);
      this.emit('stopQuestionNaire');
    });
  }
}

export default Questionnaire;
