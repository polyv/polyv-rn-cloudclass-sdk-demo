const words = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const resultTmp = {
  mainTmp(data) {
    const { totalScore, averageScore } = this.getScore(data);
    const el = document.createElement('div');
    el.setAttribute('class', 'plv-questionnaire-result-container');
    el.innerHTML = `
      <div class="qn-result-head">
        <h4>${data.questionnaireTitle}</h4>
        <ul class="qn-head-right">
          <li>
            <p>提交量</p>
            <span>${data.total}</span>
          </li>
          <li>
            <p>总分</p>
            <span>${totalScore}</span>
          </li>
          <li>
            <p>平均分</p>
            <span>${averageScore}</span>
          </li>
        </ul>
      </div>
      <div class="qn-result-body">
        ${this.getMainContent(data.data)}
      </div>
      <div class="qn-result-footer">
        <button id="questionnaireResultClose">关闭</button>
      </div>
    `.trim();
    return el;
  },

  // 生成具体问卷题目
  qnContent(data) {
    if (data.type === 'Q') return '<div class="qn-body-list">非选择题结果不显示</div>';
    let qnType = '';
    let score = '';
    switch (data.type) {
      // R单选 C多选 Q问答
      case 'R':
        qnType = '<p>单选</p>';
        break;
      case 'C':
        qnType = '<p>多选</p>';
        break;
      default:
        qnType = '<p>问答</p>';
        break;
    }
    if (data.scoreEnabled === 'Y') {
      score = `
        <span>${Number(data.score)}分题</span>
        <span class="result-average">平均分：${parseFloat(data.totalScore / data.total).toFixed()}</span>
      `;
    }
    const require = data.required === 'Y' ? '<span class="result-require">*</span>' : '';
    return  `
      <div class="qn-body-list">
        <div class="qn-body-title">
          ${qnType}${score}
        </div>
        <h4 class="qn-body-name">${data.name}${require}</h4>
        <ul>
          ${this.returnOptions(data)}
        </ul>
      </div>`;
  },

  // 生成具体选项
  options(data) {
    const { rightAnswer } = data;
    const headHoverClass = rightAnswer ? 'right-hover-color' : 'normal-hover-color';
    const rightImg = rightAnswer ? '<span class="right-option-gou"></span>' : '';
    const rightPercentClass = rightAnswer ? 'right-color' : 'normal-color';
    return `
      <li class="result-options-wrap">
        <div class="result-percent-head ${headHoverClass}" style="width: ${parseInt(data.percent)}%"></div>
        <div class="result-full"></div>
        <div class="result-percent-total">
          ${rightImg}
          <span class="result-options-list">${words.charAt(data.index)}. ${data.option}</span>
          <span class="result-options-percent ${rightPercentClass}">${data.count}票 (${data.percent}%}</span>
        </div>
      </li>
    `;
  },

  returnOptions(data) {
    const optionsData = this.getOptionsDetail(data);
    return optionsData.reduce((pre, next) => {
      return `${pre}${this.options(next)}`;
    }, '');
  },

  getMainContent(list) {
    return list.reduce((pre, next) => {
      return `${pre}${this.qnContent(next)}`.trim();
    }, '');
  },

  getSingleOptionPercent(score, total) {
    if (Number(total) === 0) return 0;
    return parseFloat((score * 100) / total).toFixed(2);
  },

  returnIsAnswer(answer, index){
    const answerCode = answer.split('').map(item => item.toUpperCase().charCodeAt() - 65).join('');
    return answerCode.indexOf(index) !== -1;
  },

  // 构造选项所需数据
  getOptionsDetail(data) {
    const arr = [];
    const { answerResult } = data;
    const allOptions = Object.keys(data).filter(item => item.indexOf('option') === 0 && data[item]);
    allOptions.forEach((item, index) => {
      arr.push({
        option: data[item],
        percent: this.getSingleOptionPercent(answerResult[index], data.total),
        rightAnswer: this.returnIsAnswer(data.answer, index),
        index,
        count: answerResult[index]
      });
    });
    return arr;
  },

  getScore(data) {
    let totalScore = 0;
    let earnScore = 0;
    const resultList = data.data;
    resultList.forEach((item) => {
      if (item.type !== 'Q') {
        totalScore += Number(item.score);
        earnScore += Number(item.totalScore);
      }
    });
    const averageScore = parseFloat(earnScore / data.total).toFixed(2);
    return { totalScore, averageScore };
  }
};

export default resultTmp;
