import './sign.scss';
import Event from 'events';

const tmp = {
  startSignin(data) {
    const el = document.createElement('div');
    el.className = 'player-signed-container';
    el.innerHTML = `
      <span data-type="close">×</span>
      <div class="signed-time" id="signTime">${data.limitTime}</div>
      <p class="sign-message">${data.message}</p>
      <button class="btn-signed" data-type="sign-in" id="btnSign">签到</buttton>
    `;
    return el;
  }
};

class Sign extends Event {
  constructor(wrap) {
    super();
    this.signTimer = null;
    this.wrap = document.getElementById(wrap);
    this.visible = false;
    this.bindEvent();
  }

  startSign(data) {
    this.wrapClose();
    this.visible = true;
    this.el = tmp.startSignin(data);
    this.wrap.appendChild(this.el);
    this.wrap.classList.add('sign-show');
    this.signTime = document.getElementById('signTime');
    this.btnSign = document.getElementById('btnSign');
    this.startCountDown(Number(data.limitTime));
  }

  stopSign() {
    clearInterval(this.signTimer);
    if (!this.btnSign) return;
    this.visible = true;
    this.btnSign.setAttribute('class', 'btn-sign-stop');
    this.btnSign.setAttribute('disabled', 'disabled');
    this.btnSign.innerHTML = '签到已截止';
    setTimeout(() => {
      this.wrapClose();
      this.emit('closeSignWebview');
    }, 3000);
  }

  startCountDown(time) {
    clearInterval(this.signTimer);
    const startTime = new Date().getTime();
    this.signTimer = setInterval(() => {
      const count = new Date().getTime() - startTime;
      const realTime = time - parseInt(count / 1000, 10);
      this.signTime.innerHTML = realTime;
      if (realTime < 1) {
        this.stopSign();
        return;
      }
    }, 500);
  }

  wrapClose() {
    if (document.getElementsByClassName('player-signed-container')[0]) {
      this.el.remove();
      this.el = null;
      this.wrap.classList.remove('sign-show');
    }
  }

  bindEvent() {
    this.wrap.addEventListener('click', (event) => {
      const type = event.target.getAttribute('data-type');
      if (!type) return;
      if (type === 'sign-in') {
        clearInterval(this.signTimer);
        this.timmer = null;
        const { btnSign } = this;
        signTime.innerHTML = '<span class="submit-sign"></span>';
        btnSign.setAttribute('class', 'btn-sign-submit');
        btnSign.setAttribute('disabled', 'disabled');
        btnSign.innerHTML = '签到成功';
        this.emit('submitSign');
        setTimeout(() => {
          this.wrapClose();
          this.emit('closeSignWebview');
        }, 3000);
      } else if (type === 'close') {
        clearInterval(this.signTimer);
        this.wrapClose();
        this.emit('closeSignWebview');
      }
    });
  }
}

export default Sign;
