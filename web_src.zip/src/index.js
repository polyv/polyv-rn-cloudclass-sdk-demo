import App from './app';

new App({
  answerCard: 'answerCard',
  questionnaire: 'questionnaire',
  lottery: 'lottery',
  sign: 'sign',
  announcement: 'announcement',
  pauseTip: 'pauseTip',
});
