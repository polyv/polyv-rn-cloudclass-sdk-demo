/**
 * 该模块用于实现web与app的通讯
 * 大致流程
 * 1、先是接收app端传递过来的消息，安卓通过 webkitBridge.registerHandler 注册事件监听，ios 通过app端调用web的全局方法
 * 2、收到app端消息后，将数据通过事件广播，app.js 模块监听事件，向响应模块发送数据并显示界面，用户填写相关表单或做相关操作
 * 3、用户操作后，安卓 通过window.WebViewJavascriptBridge.callHandler，，ios 通过调用被覆写的全局方法向app发送信息
 */

import Event from 'events';

/**
 * ios 中不适用调用 window.WebViewJavascriptBridge.callHandler向app发送信息
 * ios 通过覆写全局方法来达到 window.WebViewJavascriptBridge.callHandler 的效果
 * eq：window.chooseAnswer， 所以需要先定义全局方法
 */
window.chooseAnswer = (data) => {};
window.endQuestionnaireAnswer = (data) => {};
window.sendWinData = (data) => {};
window.abandonLottery = () => {};
window.submitSign = () => {};
window.closeWebview = () => {};
window.initWebview = () => {};
window.linkClick = (data) => {};

window.sendWKWebViewMessage = (event, data) => {
  if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers[event]) {
    window.webkit.messageHandlers[event].postMessage(data);
  }
};

class Bridge extends Event {
  constructor(){
    super();
  }

  // 向 app 发送答题卡结果
  chooseAnswer(data) {
    window.chooseAnswer(data);
    window.sendWKWebViewMessage('chooseAnswer', data);
    try {
      window.WebViewJavascriptBridge.callHandler('chooseAnswer', data);
    } catch (error) {}
  }

  // 向 app 发送问卷结果
  endQuestionnaireAnswer(data) {
    window.endQuestionnaireAnswer(data);
    window.sendWKWebViewMessage('endQuestionnaireAnswer', data);
    try {
      window.WebViewJavascriptBridge.callHandler('endQuestionnaireAnswer', data);
    } catch (error) {}
  }

  // 向 app 提交中奖信息
  sendWinData(data) {
    window.sendWinData(data);
    window.sendWKWebViewMessage('sendWinData', data);
    try {
      window.WebViewJavascriptBridge.callHandler('sendWinData', data);
    } catch (error) {}
  }

  // 向app发送放弃中奖消息
  abandonLottery() {
    window.abandonLottery();
    window.sendWKWebViewMessage('abandonLottery', '');
    try {
      window.WebViewJavascriptBridge.callHandler('abandonLottery');
    } catch (error) {}
  }

  // 向app发送签到信息
  submitSign() {
    window.submitSign();
    window.sendWKWebViewMessage('submitSign', '');
    // 不抛异常原因：ios下执行window.WebViewJavascriptBridge百分百报错，没抛错的意义
    try {
      window.WebViewJavascriptBridge.callHandler('submitSign');
    } catch (error) { }
  }

  // 向 app 发送关闭 webview
  closeWebview() {
    window.closeWebview();
    window.sendWKWebViewMessage('closeWebview', '');
    try {
      window.WebViewJavascriptBridge.callHandler('closeWebview');
    } catch (error) {}
  }

  initWebview() {
    window.initWebview();
    window.sendWKWebViewMessage('initWebview', '');
    try {
      window.WebViewJavascriptBridge.callHandler('initWebview');
    } catch (error) {}
  }

  linkClick(href) {
    window.linkClick(href);
    window.sendWKWebViewMessage('linkClick', href);
    try {
      window.WebViewJavascriptBridge.callHandler('linkClick', href);
    } catch (error) {}
  }
}

const bridge = new Bridge();

const connectWebViewJavascriptBridge = (callback) => {
  if (window.WebViewJavascriptBridge) {
    callback(WebViewJavascriptBridge)
  } else {
    document.addEventListener('WebViewJavascriptBridgeReady', function() {
      callback(WebViewJavascriptBridge)
    }, false);
   }
};

window.updateNewQuestion = (data, responseCallback = () => {}) => {
  bridge.emit('updateNewQuestion', data);
  responseCallback('收到答题信息');
};

window.hasChooseAnswer = (data, responseCallback = () => {}) => {
  bridge.emit('hasChooseAnswer', data);
  responseCallback('收到答题结果:'+ data);
};

window.testQuestion = (data, responseCallback = () => {}) => {
  bridge.emit('extraQuestionMessageHandler', data);
  responseCallback('收到额外消息:'+ data);
}


window.startQuestionNaire = (data, responseCallback = () => {}) => {
  bridge.emit('startQuestionNaire', data);
  responseCallback('收到问卷信息:'+ data);
};

window.stopQuestionNaire = (data, responseCallback = () => {}) => {
  bridge.emit('stopQuestionNaire', data);
  responseCallback('收到问卷结束:'+ data);
};

window.startLottery = (data, responseCallback = () => {}) => {
  bridge.emit('startLottery', data);
  responseCallback('收到抽奖开始:' + data);
};

window.stopLottery = (data, responseCallback = () => {}) => {
  bridge.emit('stopLottery', data);
  responseCallback('收到抽奖结束:' + data);
};

window.startSign = (data, responseCallback = () => {}) => {
  bridge.emit('startSign', data);
  responseCallback('收到签到开始' + data);
}

window.stopSign = (data, responseCallback = () => { }) => {
  bridge.emit('stopSign', data);
  responseCallback('收到签到结束' + data);
}

window.closeLotteryWinner = (data, responseCallback = () => { }) => {
  bridge.emit('closeLotteryWinner', data);
  responseCallback('收到中奖中关闭窗口' + data);
}

window.bulletin = (data, responseCallback = () => { }) => {
  bridge.emit('bulletin', data);
  responseCallback('收到公告' + data);
}

window.removeBulletin = (data, responseCallback = () => { }) => {
  bridge.emit('removeBulletin', data);
  responseCallback('收到删除公告' + data);
}

window.onStartRecord = (data, responseCallback = () => { }) => {
  bridge.emit('onStartRecord', data);
  responseCallback('收到开始直播' + data);
}

window.onPauseRecord = (data, responseCallback = () => { }) => {
  bridge.emit('onPauseRecord', data);
  responseCallback('收到暂停直播' + data);
}

window.onExitRecord = (data, responseCallback = () => { }) => {
  bridge.emit('onExitRecord', data);
  responseCallback('收到下课事件' + data);
}

connectWebViewJavascriptBridge((webkitBridge) => {
  webkitBridge.init((message, responseCallback) => {});
  bridge.emit('bridgeInit');
  // 注册相应事件
  webkitBridge.registerHandler('updateNewQuestion', window.updateNewQuestion);
  webkitBridge.registerHandler('hasChooseAnswer', window.hasChooseAnswer);
  webkitBridge.registerHandler('testQuestion', window.testQuestion);
  webkitBridge.registerHandler('startQuestionNaire', window.startQuestionNaire);
  webkitBridge.registerHandler('stopQuestionNaire', window.stopQuestionNaire);
  webkitBridge.registerHandler('startLottery', window.startLottery);
  webkitBridge.registerHandler('stopLottery', window.stopLottery);
  webkitBridge.registerHandler('startSign', window.startSign);
  webkitBridge.registerHandler('stopSign', window.stopSign);
  webkitBridge.registerHandler('closeLotteryWinner', window.closeLotteryWinner);
  webkitBridge.registerHandler('bulletin', window.bulletin);
  webkitBridge.registerHandler('removeBulletin', window.removeBulletin);
  webkitBridge.registerHandler('onStartRecord', window.onStartRecord);
  webkitBridge.registerHandler('onPauseRecord', window.onPauseRecord);
  webkitBridge.registerHandler('onExitRecord', window.onExitRecord);
});

export default bridge;
